import React from "react";

export default function AlkebulanTravelSite() {
  return (
    <div className="bg-white text-black font-serif">
      <header className="bg-gradient-to-r from-yellow-500 via-red-500 to-green-600 text-white py-16 px-8 text-center">
        <h1 className="text-4xl font-bold mb-4">Alkebulan Travel and Tours</h1>
        <p className="text-lg italic">Discover Alkebulan Through Our Eyes</p>
      </header>
      <main className="p-6 text-center">
        <p className="text-xl mt-6">Full site content will be added here.</p>
      </main>
    </div>
  );
}
